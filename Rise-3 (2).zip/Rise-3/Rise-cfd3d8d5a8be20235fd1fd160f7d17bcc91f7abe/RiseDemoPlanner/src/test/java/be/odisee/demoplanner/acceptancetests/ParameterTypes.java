package be.odisee.demoplanner.acceptancetests;

public class ParameterTypes {

}
